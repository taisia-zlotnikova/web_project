import datetime
import os

from flask import Flask, render_template, request, make_response, session
# noinspection PyUnresolvedReferences
from werkzeug.utils import redirect
from flask_login import LoginManager, login_user, login_required, logout_user, current_user

from BASA.users import User
from BASA.news import News
from BASA.forms.user import RegisterForm
from BASA.forms.loginform import LoginForm
from BASA.forms.news import NewsForm

from requests import get

from BASA import db_session, news_api

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
login_manager = LoginManager()
login_manager.init_app(app)

birthday = ''


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='авторизация', form=form)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.route("/")
def index():
    db_sess = db_session.create_session()
    # news = db_sess.query(News).filter(News.is_private != True)
    if current_user.is_authenticated:
        news = db_sess.query(News).filter(
            (News.user == current_user) | (News.is_private != True))
    else:
        news = db_sess.query(News).filter(News.is_private != True)
    return render_template("index.html", news=news)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    global birthday
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='регистрация',
                                   form=form,
                                   message="пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='регистрация',
                                   form=form,
                                   message="такой пользователь уже есть")
        user = User(
            name=form.name.data,
            email=form.email.data,
            birthday=form.birthday.data
        )
        birthday = form.birthday.data
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
        # return redirect('/login')
    return render_template('register.html', title='регистрация', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/znak')
def znak():
    zodiak, opis, year, opis_year, goroskop = opr_znaka(birthday)
    return render_template('znak.html', title='мой знак',
                           zodiak=zodiak, opisanie=opis, year=year, opis_year=opis_year, goroskop=goroskop)


def opr_znaka(data):
    d, m, y = map(int, data.split('.'))
    zodiak = 12
    opisania = ['Овны это неутомимые борцы и неисправимые оптимисты. Их упрямство достойно войти в пословицы.',
                'Тельцы совершенно уверены, что появились на свет для того, чтобы сделать мир лучше, и в этом они почти не ошибаются.',
                'Близнецы многолики, переменчивы и непредсказуемы. С ними всегда весело и интересно, но очень редко бывает спокойно.',
                'Стихия Раков – душевные порывы, тонкие переживания, высокие чувства. Все грубое и материальное представляется им малоинтересным',
                'Львов невозможно не заметить: везде, где появляются представители знака, они оказываются в центре внимания.',
                'Считается, что именно под знаком Девы появляются на свет самые умные люди. Они отличаются незаурядным интеллектом',
                'Представители знака отличаются хорошими манерами, дружелюбием и оптимизмом. Только очень терпеливый и настойчивый человек способен испортить Весам настроение.',
                'Скорпионы – сложные, многогранные и очень привлекательные люди. Они способны очаровать любого, но никогда не делают этого в корыстных целях.',
                'Азарт – вот сила, которая ведет Стрельцов по жизни, порой приводя в сложные, нелепые и смешные ситуации.',
                'Трудолюбие, здравомыслие и правильная оценка собственных возможностей – три кита успеха Козерогов.',
                'Водолеи очень самостоятельны и самодостаточны. У представителей знака очень сильная интуиция, но пользоваться ею правильно им не всегда удается.',
                'У Рыб легкий, приятный характер, слегка окрашенный в романтические или меланхолические тона.',
                '']
    zodiaks = ['овен', 'телец', 'близнецы', 'рак', 'лев', 'дева', 'весы', 'скорпион', 'стрелец', 'козирог', 'водолей',
               'рыбы', 'не определен']
    goroskops = ['Сегодня все дела, связанные с наведением и соблюдением порядка, будут даваться Овну легче обычного!',
                'Сегодня – день, когда окружающие будут настроены к Тельцу благосклонно и готовы обсудить самые смелые его предложения. Поэтому если у Тельца есть готовые идеи, которые он не решался озвучить, ему стоит наконец-то произнести их вслух. ',
                'Сегодня Близнецам следует прислушиваться к советам окружающих – даже если они считают, что совершенно в них не нуждаются.',
                'Сегодня звезды гороскопа советуют Раку держать свои идеи (особенно новаторские) при себе. Они вряд ли найдут понимание у окружающих, а вот навредить могут.',
                'Сегодня звезды гороскопа советуют Льву не изобретать велосипед. Прежде чем предложить свой вариант, Льву стоит посмотреть на то, как этот же вопрос до него решали другие. Воспользовавшись чужими идеями, Лев сегодня сэкономит массу времени и сил.',
                'Сегодня Деве следует задуматься над укреплением своего авторитета. Обаяние Девы откроет для нее пути к сердцам людей, однако эту симпатию необходимо подкрепить делом',
                'Сегодня даже самые простые, рутинные дела у Весов могут продвигаться кое-как, со скрипом. звезды гороскопа советуют сегодня Весам расслабиться и плыть по течению',
                'Сегодня Скорпиона может буквально распирать от желания поделиться с окружающими какими-то новаторскими идеями и планами. Однако звезды гороскопа предупреждают, что делать это надо постепенно и осторожно.',
                'Сегодня день Стрельца пройдет под бумажным флагом! Даже если в обычные дни он тяготится бюрократией и писаниной, сегодня ему следует целый день держать под рукой рабочий блокнот, старательно занося в него все текущие дела и планы.',
                'Сегодня Козерог, вполне возможно, захочет в чем-то рискнуть, но звезды гороскопа делать это категорически не советуют: его представление о происходящем не учитывает каких-то важных факторов.',
                'Сегодня – тот самый день, когда инициатива Водолея может оказаться наказуемой. Или привести к последствиям, которых Водолей совсем не ожидал. Другими словами, девиз этого дня простой: «Не умничай, не выделяйся!».',
                'Сегодня Рыбам придется уподобиться герою фильма «Всегда говори «да». Ситуация потребует от них то и дело высказывать свою лояльность, улыбаться и соглашаться!',
                'гороскоп не найден(']

    if m == 3 and d >= 21 or m == 4 and d <= 20:
        zodiak = 0
    elif m == 4 and d >= 21 or m == 5 and d <= 20:
        zodiak = 1
    elif m == 5 and d >= 21 or m == 6 and d <= 20:
        zodiak = 2
    elif m == 6 and d >= 21 or m == 7 and d <= 22:
        zodiak = 3
    elif m == 7 and d >= 23 or m == 8 and d <= 22:
        zodiak = 4
    elif m == 8 and d >= 23 or m == 9 and d <= 22:
        zodiak = 5
    elif m == 9 and d >= 23 or m == 10 and d <= 22:
        zodiak = 6
    elif m == 10 and d >= 23 or m == 11 and d <= 21:
        zodiak = 7
    elif m == 11 and d >= 22 or m == 12 and d <= 21:
        zodiak = 8
    elif m == 12 and d >= 22 or m == 1 and d <= 19:
        zodiak = 9
    elif m == 1 and d >= 20 or m == 2 and d <= 18:
        zodiak = 10
    elif m == 2 and d >= 19 or m == 3 and d <= 20:
        zodiak = 11

    opis = opisania[zodiak]
    goroskop = goroskops[zodiak]
    zodiak = zodiaks[zodiak]

    y %= 12
    opis_years = ['Чересчур активные и неутомимые. Любят держать других в движении и напряжении.',
                  'Петухи эффективны в работе и заслуживают доверия в дружбе. А еще просто поразительно — насколько они пунктуальны!',
                  'Собаки дружелюбны, щедры и справедливы в отношении окружающих. Собака — надежная «жилетка» для слез в моменты печали и отличный собеседник для разговоров по душам.',
                  'Такие люди обладают приятным внутренним драйвом и ценят честность. Но самое приятное — они не скупятся на проявление чувств, если по-настоящему влюблены.',
                  'По своей сути Крысы — люди щедрые и невероятно умные, а вовсе не изворотливые. Перед вами прирожденные лидеры.',
                  'Быки — главные трудоголики из всей дюжины. Это очень ответственные и надежные люди.',
                  'Представители этого знака известны своей храбростью. Тигры невероятно харизматичны и часто оказываются на руководящих должностях',
                  'Кролики такие же сообразительные, как и их прототипы в природе. Кролики очень ласковые и внимательные друзья, партнеры и коллеги.',
                  'Драконы очень креативные и гибкие, легко адаптируются под различные «условия игры» — их вкусы могут резко измениться, но они по-прежнему остаются теми же страстными и мотивированными героями.',
                  'Проницательный характер, мудрость и общая утонченность змей, безусловно, делают их сильными личностями.',
                  'Лошадь, как и положено символу, очаровательная и искренняя в своих проявлениях и реакциях',
                  'Люди, рожденные под этим знаком, известны своим безупречным вкусом, индивидуальным стилем и изысканностью в манерах. ']
    years = ['обезьяны', 'петуха', 'собаки', 'свиньи', 'крысы', 'быка', 'тигра', 'кролика', 'дракона', 'змеи', 'лошади',
             'козы']
    year = years[y]
    opis_year = opis_years[y]

    return zodiak, opis, year, opis_year, goroskop


@app.route('/news', methods=['GET', 'POST'])
@login_required
def add_news():
    form = NewsForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        news = News()
        news.title = form.title.data
        news.content = form.content.data
        news.is_private = form.is_private.data
        current_user.news.append(news)
        db_sess.merge(current_user)
        db_sess.commit()
        return redirect('/')
    return render_template('news.html', title='добавление гороскопа',
                           form=form)


@app.route('/news/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_news(id):
    form = NewsForm()
    if request.method == "GET":
        db_sess = db_session.create_session()
        news = db_sess.query(News).filter(News.id == id,
                                          News.user == current_user
                                          ).first()
        if news:
            form.title.data = news.title
            form.content.data = news.content
            form.is_private.data = news.is_private
        else:
            os.abort(404)
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        news = db_sess.query(News).filter(News.id == id,
                                          News.user == current_user
                                          ).first()
        if news:
            news.title = form.title.data
            news.content = form.content.data
            news.is_private = form.is_private.data
            db_sess.commit()
            return redirect('/')
        else:
            os.abort(404)
    return render_template('news.html',
                           title='Редактирование гороскопа',
                           form=form
                           )


@app.route('/news_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def news_delete(id):
    db_sess = db_session.create_session()
    news = db_sess.query(News).filter(News.id == id,
                                      News.user == current_user
                                      ).first()
    if news:
        db_sess.delete(news)
        db_sess.commit()
    else:
        os.abort(404)
    return redirect('/')


def main():
    db_session.global_init('db/goroskop.db')
    db_sess = db_session.create_session()
    app.register_blueprint(news_api.blueprint)
    app.run(port=8000, host='localhost')


if __name__ == '__main__':
    main()
